# This file is intentionally left blank to prevent implicit imports.
# Individual CRUD modules should be imported directly, e.g.,
# from app.crud import crud_customer